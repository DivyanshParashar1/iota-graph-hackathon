import os
import logging

from .._httpx import httpx

logger: logging.Logger = logging.getLogger("langsmith._openapi_client")
# Each backend logs under its own package name, so this has to follow the one in use.
httpx_logger: logging.Logger = logging.getLogger(httpx.__name__)


def _basic_config() -> None:
    # e.g. [2023-10-05 14:12:26 - langsmith._openapi_client._base_client:818 - DEBUG] HTTP Request: POST http://127.0.0.1:4010/foo/bar "200 OK"
    logging.basicConfig(
        format="[%(asctime)s - %(name)s:%(lineno)d - %(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def setup_logging() -> None:
    env = os.environ.get("LANGCHAIN_LOG")
    if env == "debug":
        _basic_config()
        logger.setLevel(logging.DEBUG)
        httpx_logger.setLevel(logging.DEBUG)
    elif env == "info":
        _basic_config()
        logger.setLevel(logging.INFO)
        httpx_logger.setLevel(logging.INFO)
