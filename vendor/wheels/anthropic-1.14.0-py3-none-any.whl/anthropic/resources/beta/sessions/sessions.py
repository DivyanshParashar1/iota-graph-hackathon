from __future__ import annotations

from typing import Dict, List, Union, Iterable, Optional
from datetime import datetime
from itertools import chain
from typing_extensions import Literal

import httpx2

from .events import (
    Events,
    AsyncEvents,
    EventsWithRawResponse,
    AsyncEventsWithRawResponse,
    EventsWithStreamingResponse,
    AsyncEventsWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import is_given, path_template, strip_not_given
from .resources import (
    Resources,
    AsyncResources,
    ResourcesWithRawResponse,
    AsyncResourcesWithRawResponse,
    ResourcesWithStreamingResponse,
    AsyncResourcesWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ....pagination import SyncBidirectionalPageCursor, AsyncBidirectionalPageCursor
from ....types.beta import (
    session_create_params,
)
from ...._base_client import AsyncPaginator, make_request_options
from ....lib._tracing import sessions_create_request_attributes
from .threads.threads import (
    Threads,
    AsyncThreads,
    ThreadsWithRawResponse,
    AsyncThreadsWithRawResponse,
    ThreadsWithStreamingResponse,
    AsyncThreadsWithStreamingResponse,
)
from ....types.anthropic_beta_param import AnthropicBetaParam
from ....types.beta.beta_managed_agents_session import BetaManagedAgentsSession
from ....types.beta.beta_managed_agents_deleted_session import BetaManagedAgentsDeletedSession
from ....types.beta.beta_managed_agents_budget_limit_param import BetaManagedAgentsBudgetLimitParam
from ....types.beta.beta_managed_agents_session_agent_update_param import BetaManagedAgentsSessionAgentUpdateParam

__all__ = ["Sessions", "AsyncSessions"]


class Sessions(SyncAPIResource):
    @cached_property
    def events(self) -> Events:
        return Events(self._client)

    @cached_property
    def resources(self) -> Resources:
        return Resources(self._client)

    @cached_property
    def threads(self) -> Threads:
        return Threads(self._client)

    @cached_property
    def with_raw_response(self) -> SessionsWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return SessionsWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SessionsWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return SessionsWithStreamingResponse(self)

    def create(
        self,
        *,
        agent: session_create_params.Agent,
        environment_id: str,
        budget: BetaManagedAgentsBudgetLimitParam | Omit = omit,
        initial_events: Iterable[session_create_params.InitialEvent] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        resources: Iterable[session_create_params.Resource] | Omit = omit,
        title: Optional[str] | Omit = omit,
        vault_ids: SequenceNotStr[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """Create Session

        Args:
          agent: Agent identifier.

        Accepts the `agent` ID string, which pins the latest version
              for the session, or an `agent` object with both id and version specified.

          environment_id: ID of the `environment` defining the container configuration for this session.

          budget: Enforced spend ceiling for the session. Omit to create an uncapped session.
              Every model the session can run — the agent's model and each callable agent's
              model — must have a public list price, or the request is rejected with reason
              `model_not_budgetable`.

          initial_events: Initial events to send to the `session` at creation, processed in order.
              Supports `user.message` and `user.define_outcome` events. Maximum 50 events.

          metadata: Arbitrary key-value metadata attached to the session. Maximum 16 pairs, keys up
              to 64 chars, values up to 512 chars.

          resources: Resources (e.g. repositories, files) to mount into the session's container.

          title: Human-readable session title.

          vault_ids: Vault IDs for stored credentials the agent can use during the session.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._post(
            "/v1/sessions?beta=true",
            body={
                "agent": agent,
                "environment_id": environment_id,
                "budget": budget,
                "initial_events": initial_events,
                "metadata": metadata,
                "resources": resources,
                "title": title,
                "vault_ids": vault_ids,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.create",
                span_route="/v1/sessions",
                span_attributes=sessions_create_request_attributes,
                span_created_id="anthropic.session.id",
            ),
            cast_to=BetaManagedAgentsSession,
        )

    def retrieve(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """
        Get Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._get(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.retrieve",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )

    def update(
        self,
        session_id: str,
        *,
        agent: BetaManagedAgentsSessionAgentUpdateParam | Omit = omit,
        budget: Optional[BetaManagedAgentsBudgetLimitParam] | Omit = omit,
        metadata: Optional[Dict[str, Optional[str]]] | Omit = omit,
        title: Optional[str] | Omit = omit,
        vault_ids: SequenceNotStr[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """Update Session

        Args:
          agent: Agent configuration update.

        Only `tools` and `mcp_servers` are updatable
              mid-session. Only valid for sessions created from an agent or deployment
              reference. The session must not be running.

          budget: Enforced spend ceiling for the session. Set an object to replace the budget of a
              session that was created with one, or `null` to remove it; omit to preserve. A
              budget cannot be added to a session created without one (rejected with reason
              `budget_create_only`), and a removed budget cannot be re-added. Allowed in any
              non-terminated status. Lowering `max_list_cost` to at or below the session's
              consumed list cost is rejected with reason `budget_not_raised`, and every model
              the session can run must have a public list price or the request is rejected
              with reason `model_not_budgetable`.

          metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
              Omit the field to preserve.

          title: Human-readable session title.

          vault_ids: Vault IDs (`vlt_*`) to attach to the session. Not yet supported; requests
              setting this field are rejected. Reserved for future use.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._post(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            body={
                "agent": agent,
                "budget": budget,
                "metadata": metadata,
                "title": title,
                "vault_ids": vault_ids,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.update",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )

    def list(
        self,
        *,
        agent_id: str | Omit = omit,
        agent_version: int | Omit = omit,
        created_at_gt: Union[str, datetime] | Omit = omit,
        created_at_gte: Union[str, datetime] | Omit = omit,
        created_at_lt: Union[str, datetime] | Omit = omit,
        created_at_lte: Union[str, datetime] | Omit = omit,
        deployment_id: str | Omit = omit,
        include_archived: bool | Omit = omit,
        limit: int | Omit = omit,
        memory_store_id: str | Omit = omit,
        order: Literal["asc", "desc"] | Omit = omit,
        page: str | Omit = omit,
        statuses: List[Literal["rescheduling", "running", "idle", "terminated"]] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncBidirectionalPageCursor[BetaManagedAgentsSession]:
        """
        List Sessions

        Args:
          agent_id: Filter sessions created with this agent ID.

          agent_version: Filter by agent version. Only applies when `agent_id` is also set.

          created_at_gt: Return sessions created after this time (exclusive).

          created_at_gte: Return sessions created at or after this time (inclusive).

          created_at_lt: Return sessions created before this time (exclusive).

          created_at_lte: Return sessions created at or before this time (inclusive).

          deployment_id: Filter sessions created by this deployment ID.

          include_archived: When true, includes archived sessions. Default: false (exclude archived).

          limit: Maximum number of results to return.

          memory_store_id: Filter sessions whose resources contain a `memory_store` with this memory store
              ID.

          order: Sort direction for results, ordered by `created_at`. Defaults to `desc` (newest
              first).

          page: Opaque pagination cursor from a previous response.

          statuses: Filter by session status. Repeat the parameter to match any of multiple
              statuses.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._get_api_list(
            "/v1/sessions?beta=true",
            page=SyncBidirectionalPageCursor[BetaManagedAgentsSession],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "agent_id": agent_id,
                    "agent_version": agent_version,
                    "created_at[gt]": created_at_gt,
                    "created_at[gte]": created_at_gte,
                    "created_at[lt]": created_at_lt,
                    "created_at[lte]": created_at_lte,
                    "deployment_id": deployment_id,
                    "include_archived": include_archived,
                    "limit": limit,
                    "memory_store_id": memory_store_id,
                    "order": order,
                    "page": page,
                    "statuses": statuses,
                },
                span_name="anthropic.sessions.list",
                span_route="/v1/sessions",
            ),
            model=BetaManagedAgentsSession,
        )

    def delete(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsDeletedSession:
        """
        Delete Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._delete(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.delete",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsDeletedSession,
        )

    def archive(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """
        Archive Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._post(
            path_template("/v1/sessions/{session_id}/archive?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.archive",
                span_route="/v1/sessions/{session_id}/archive",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )


class AsyncSessions(AsyncAPIResource):
    @cached_property
    def events(self) -> AsyncEvents:
        return AsyncEvents(self._client)

    @cached_property
    def resources(self) -> AsyncResources:
        return AsyncResources(self._client)

    @cached_property
    def threads(self) -> AsyncThreads:
        return AsyncThreads(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSessionsWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSessionsWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSessionsWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return AsyncSessionsWithStreamingResponse(self)

    async def create(
        self,
        *,
        agent: session_create_params.Agent,
        environment_id: str,
        budget: BetaManagedAgentsBudgetLimitParam | Omit = omit,
        initial_events: Iterable[session_create_params.InitialEvent] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        resources: Iterable[session_create_params.Resource] | Omit = omit,
        title: Optional[str] | Omit = omit,
        vault_ids: SequenceNotStr[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """Create Session

        Args:
          agent: Agent identifier.

        Accepts the `agent` ID string, which pins the latest version
              for the session, or an `agent` object with both id and version specified.

          environment_id: ID of the `environment` defining the container configuration for this session.

          budget: Enforced spend ceiling for the session. Omit to create an uncapped session.
              Every model the session can run — the agent's model and each callable agent's
              model — must have a public list price, or the request is rejected with reason
              `model_not_budgetable`.

          initial_events: Initial events to send to the `session` at creation, processed in order.
              Supports `user.message` and `user.define_outcome` events. Maximum 50 events.

          metadata: Arbitrary key-value metadata attached to the session. Maximum 16 pairs, keys up
              to 64 chars, values up to 512 chars.

          resources: Resources (e.g. repositories, files) to mount into the session's container.

          title: Human-readable session title.

          vault_ids: Vault IDs for stored credentials the agent can use during the session.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return await self._post(
            "/v1/sessions?beta=true",
            body={
                "agent": agent,
                "environment_id": environment_id,
                "budget": budget,
                "initial_events": initial_events,
                "metadata": metadata,
                "resources": resources,
                "title": title,
                "vault_ids": vault_ids,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.create",
                span_route="/v1/sessions",
                span_attributes=sessions_create_request_attributes,
                span_created_id="anthropic.session.id",
            ),
            cast_to=BetaManagedAgentsSession,
        )

    async def retrieve(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """
        Get Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return await self._get(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.retrieve",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )

    async def update(
        self,
        session_id: str,
        *,
        agent: BetaManagedAgentsSessionAgentUpdateParam | Omit = omit,
        budget: Optional[BetaManagedAgentsBudgetLimitParam] | Omit = omit,
        metadata: Optional[Dict[str, Optional[str]]] | Omit = omit,
        title: Optional[str] | Omit = omit,
        vault_ids: SequenceNotStr[str] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """Update Session

        Args:
          agent: Agent configuration update.

        Only `tools` and `mcp_servers` are updatable
              mid-session. Only valid for sessions created from an agent or deployment
              reference. The session must not be running.

          budget: Enforced spend ceiling for the session. Set an object to replace the budget of a
              session that was created with one, or `null` to remove it; omit to preserve. A
              budget cannot be added to a session created without one (rejected with reason
              `budget_create_only`), and a removed budget cannot be re-added. Allowed in any
              non-terminated status. Lowering `max_list_cost` to at or below the session's
              consumed list cost is rejected with reason `budget_not_raised`, and every model
              the session can run must have a public list price or the request is rejected
              with reason `model_not_budgetable`.

          metadata: Metadata patch. Set a key to a string to upsert it, or to null to delete it.
              Omit the field to preserve.

          title: Human-readable session title.

          vault_ids: Vault IDs (`vlt_*`) to attach to the session. Not yet supported; requests
              setting this field are rejected. Reserved for future use.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return await self._post(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            body={
                "agent": agent,
                "budget": budget,
                "metadata": metadata,
                "title": title,
                "vault_ids": vault_ids,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.update",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )

    def list(
        self,
        *,
        agent_id: str | Omit = omit,
        agent_version: int | Omit = omit,
        created_at_gt: Union[str, datetime] | Omit = omit,
        created_at_gte: Union[str, datetime] | Omit = omit,
        created_at_lt: Union[str, datetime] | Omit = omit,
        created_at_lte: Union[str, datetime] | Omit = omit,
        deployment_id: str | Omit = omit,
        include_archived: bool | Omit = omit,
        limit: int | Omit = omit,
        memory_store_id: str | Omit = omit,
        order: Literal["asc", "desc"] | Omit = omit,
        page: str | Omit = omit,
        statuses: List[Literal["rescheduling", "running", "idle", "terminated"]] | Omit = omit,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[BetaManagedAgentsSession, AsyncBidirectionalPageCursor[BetaManagedAgentsSession]]:
        """
        List Sessions

        Args:
          agent_id: Filter sessions created with this agent ID.

          agent_version: Filter by agent version. Only applies when `agent_id` is also set.

          created_at_gt: Return sessions created after this time (exclusive).

          created_at_gte: Return sessions created at or after this time (inclusive).

          created_at_lt: Return sessions created before this time (exclusive).

          created_at_lte: Return sessions created at or before this time (inclusive).

          deployment_id: Filter sessions created by this deployment ID.

          include_archived: When true, includes archived sessions. Default: false (exclude archived).

          limit: Maximum number of results to return.

          memory_store_id: Filter sessions whose resources contain a `memory_store` with this memory store
              ID.

          order: Sort direction for results, ordered by `created_at`. Defaults to `desc` (newest
              first).

          page: Opaque pagination cursor from a previous response.

          statuses: Filter by session status. Repeat the parameter to match any of multiple
              statuses.

          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return self._get_api_list(
            "/v1/sessions?beta=true",
            page=AsyncBidirectionalPageCursor[BetaManagedAgentsSession],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "agent_id": agent_id,
                    "agent_version": agent_version,
                    "created_at[gt]": created_at_gt,
                    "created_at[gte]": created_at_gte,
                    "created_at[lt]": created_at_lt,
                    "created_at[lte]": created_at_lte,
                    "deployment_id": deployment_id,
                    "include_archived": include_archived,
                    "limit": limit,
                    "memory_store_id": memory_store_id,
                    "order": order,
                    "page": page,
                    "statuses": statuses,
                },
                span_name="anthropic.sessions.list",
                span_route="/v1/sessions",
            ),
            model=BetaManagedAgentsSession,
        )

    async def delete(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsDeletedSession:
        """
        Delete Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return await self._delete(
            path_template("/v1/sessions/{session_id}?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.delete",
                span_route="/v1/sessions/{session_id}",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsDeletedSession,
        )

    async def archive(
        self,
        session_id: str,
        *,
        betas: List[AnthropicBetaParam] | Omit = omit,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> BetaManagedAgentsSession:
        """
        Archive Session

        Args:
          betas: Optional header to specify the beta version(s) you want to use.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not session_id:
            raise ValueError(f"Expected a non-empty value for `session_id` but received {session_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "anthropic-beta": ",".join(chain((str(e) for e in betas), ["managed-agents-2026-04-01"]))
                    if is_given(betas)
                    else not_given,
                    "anthropic-workspace-id": workspace_id,
                }
            ),
            **(extra_headers or {}),
        }
        extra_headers = {"anthropic-beta": "managed-agents-2026-04-01", **(extra_headers or {})}
        return await self._post(
            path_template("/v1/sessions/{session_id}/archive?beta=true", session_id=session_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.sessions.archive",
                span_route="/v1/sessions/{session_id}/archive",
                span_attributes={"anthropic.session.id": session_id},
            ),
            cast_to=BetaManagedAgentsSession,
        )


class SessionsWithRawResponse:
    def __init__(self, sessions: Sessions) -> None:
        self._sessions = sessions

        self.create = to_raw_response_wrapper(
            sessions.create,
        )
        self.retrieve = to_raw_response_wrapper(
            sessions.retrieve,
        )
        self.update = to_raw_response_wrapper(
            sessions.update,
        )
        self.list = to_raw_response_wrapper(
            sessions.list,
        )
        self.delete = to_raw_response_wrapper(
            sessions.delete,
        )
        self.archive = to_raw_response_wrapper(
            sessions.archive,
        )

    @cached_property
    def events(self) -> EventsWithRawResponse:
        return EventsWithRawResponse(self._sessions.events)

    @cached_property
    def resources(self) -> ResourcesWithRawResponse:
        return ResourcesWithRawResponse(self._sessions.resources)

    @cached_property
    def threads(self) -> ThreadsWithRawResponse:
        return ThreadsWithRawResponse(self._sessions.threads)


class AsyncSessionsWithRawResponse:
    def __init__(self, sessions: AsyncSessions) -> None:
        self._sessions = sessions

        self.create = async_to_raw_response_wrapper(
            sessions.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            sessions.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            sessions.update,
        )
        self.list = async_to_raw_response_wrapper(
            sessions.list,
        )
        self.delete = async_to_raw_response_wrapper(
            sessions.delete,
        )
        self.archive = async_to_raw_response_wrapper(
            sessions.archive,
        )

    @cached_property
    def events(self) -> AsyncEventsWithRawResponse:
        return AsyncEventsWithRawResponse(self._sessions.events)

    @cached_property
    def resources(self) -> AsyncResourcesWithRawResponse:
        return AsyncResourcesWithRawResponse(self._sessions.resources)

    @cached_property
    def threads(self) -> AsyncThreadsWithRawResponse:
        return AsyncThreadsWithRawResponse(self._sessions.threads)


class SessionsWithStreamingResponse:
    def __init__(self, sessions: Sessions) -> None:
        self._sessions = sessions

        self.create = to_streamed_response_wrapper(
            sessions.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            sessions.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            sessions.update,
        )
        self.list = to_streamed_response_wrapper(
            sessions.list,
        )
        self.delete = to_streamed_response_wrapper(
            sessions.delete,
        )
        self.archive = to_streamed_response_wrapper(
            sessions.archive,
        )

    @cached_property
    def events(self) -> EventsWithStreamingResponse:
        return EventsWithStreamingResponse(self._sessions.events)

    @cached_property
    def resources(self) -> ResourcesWithStreamingResponse:
        return ResourcesWithStreamingResponse(self._sessions.resources)

    @cached_property
    def threads(self) -> ThreadsWithStreamingResponse:
        return ThreadsWithStreamingResponse(self._sessions.threads)


class AsyncSessionsWithStreamingResponse:
    def __init__(self, sessions: AsyncSessions) -> None:
        self._sessions = sessions

        self.create = async_to_streamed_response_wrapper(
            sessions.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            sessions.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            sessions.update,
        )
        self.list = async_to_streamed_response_wrapper(
            sessions.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            sessions.delete,
        )
        self.archive = async_to_streamed_response_wrapper(
            sessions.archive,
        )

    @cached_property
    def events(self) -> AsyncEventsWithStreamingResponse:
        return AsyncEventsWithStreamingResponse(self._sessions.events)

    @cached_property
    def resources(self) -> AsyncResourcesWithStreamingResponse:
        return AsyncResourcesWithStreamingResponse(self._sessions.resources)

    @cached_property
    def threads(self) -> AsyncThreadsWithStreamingResponse:
        return AsyncThreadsWithStreamingResponse(self._sessions.threads)
